# QT5 Puppet Module for Boxen

## Usage

```puppet
include qt5
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
* `xquartz`
